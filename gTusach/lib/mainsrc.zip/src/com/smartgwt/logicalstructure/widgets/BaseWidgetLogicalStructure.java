package com.smartgwt.logicalstructure.widgets;

import com.smartgwt.logicalstructure.core.LogicalStructureObject;

public class BaseWidgetLogicalStructure extends LogicalStructureObject {
}
