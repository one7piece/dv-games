package com.smartgwt.logicalstructure.core;

public class LogicalStructureObject {
    public String scClassName;
    public String logicalStructureErrors;
}
