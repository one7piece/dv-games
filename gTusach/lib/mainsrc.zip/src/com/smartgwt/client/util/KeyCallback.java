package com.smartgwt.client.util;

public interface KeyCallback {

    void execute(String keyName);
}
