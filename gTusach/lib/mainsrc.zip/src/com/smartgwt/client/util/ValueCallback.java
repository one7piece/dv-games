package com.smartgwt.client.util;


public interface ValueCallback {
    void execute(String value);
}
