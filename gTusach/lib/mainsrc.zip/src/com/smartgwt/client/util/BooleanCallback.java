package com.smartgwt.client.util;


public interface BooleanCallback {

    void execute(Boolean value);
}
