
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to Drag.
 * @see com.smartgwt.client.types.DragDataAction
 */
public interface Drag {
}
