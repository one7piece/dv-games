
package com.smartgwt.client.docs;

/**
 * @see com.smartgwt.client.widgets.grid.ListGrid#clearRowErrors
 */
public interface Validtion {
}
