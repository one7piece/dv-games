
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to FlatFields.
 * @see com.smartgwt.client.data.DSRequest#getUseFlatFields
 * @see com.smartgwt.client.data.DSRequest#getUseFlatHeaderFields
 * @see com.smartgwt.client.data.WSRequest#getUseFlatFields
 */
public interface FlatFields {
}
