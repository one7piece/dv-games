
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to Scroll.
 * @see com.smartgwt.client.widgets.Scrollbar#setScrollTarget
 */
public interface Scroll {
}
