
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to Track.
 * @see com.smartgwt.client.widgets.Scrollbar#getBtnSize
 * @see com.smartgwt.client.widgets.Scrollbar#getShowTrackEnds
 * @see com.smartgwt.client.widgets.Scrollbar#getShowTrackButtons
 * @see com.smartgwt.client.widgets.Scrollbar#getTrackEndWidth
 * @see com.smartgwt.client.widgets.Scrollbar#getTrackEndHeight
 */
public interface Track {
}
