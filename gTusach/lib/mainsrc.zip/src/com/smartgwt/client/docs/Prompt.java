
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to Prompt.
 */
public interface Prompt {
}
