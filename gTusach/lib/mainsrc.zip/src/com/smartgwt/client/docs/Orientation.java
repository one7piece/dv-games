
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to Orientation.
 * @see com.smartgwt.client.types.Orientation
 */
public interface Orientation {
}
