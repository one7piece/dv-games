
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to Display.
 * @see com.smartgwt.client.widgets.grid.ListGrid#getFieldName
 * @see com.smartgwt.client.widgets.grid.ListGrid#getFieldNum
 * @see com.smartgwt.client.widgets.grid.ListGrid#getSummaryTitle
 */
public interface Display {
}
