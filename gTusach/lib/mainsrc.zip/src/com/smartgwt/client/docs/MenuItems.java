
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to MenuItems.
 * @see com.smartgwt.client.widgets.menu.Menu#getItem
 * @see com.smartgwt.client.widgets.menu.Menu#getItemNum
 */
public interface MenuItems {
}
