
package com.smartgwt.client.docs;

/**
 * Fields with values calculated from other fields in the grid.
 * @see com.smartgwt.client.widgets.grid.ListGrid#getBadFormulaResultValue
 * @see com.smartgwt.client.widgets.grid.ListGrid#getCanAddFormulaFields
 */
public interface FormulaFields {
}
