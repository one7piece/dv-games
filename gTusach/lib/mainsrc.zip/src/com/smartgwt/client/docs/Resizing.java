
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to Resizing.
 * @see com.smartgwt.client.widgets.Window#getCanDragResize
 */
public interface Resizing {
}
