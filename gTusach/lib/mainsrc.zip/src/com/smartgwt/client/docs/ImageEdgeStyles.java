
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to ImageEdgeStyles.
 * @see com.smartgwt.client.widgets.EdgedCanvas#getEdgeStyleName
 * @see com.smartgwt.client.widgets.EdgedCanvas#getAddEdgeStyleSuffix
 */
public interface ImageEdgeStyles {
}
