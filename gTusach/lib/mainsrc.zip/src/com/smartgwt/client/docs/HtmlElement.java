
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to HtmlElement.
 * @see com.smartgwt.client.widgets.Canvas#setHtmlElement
 * @see com.smartgwt.client.widgets.Canvas#setHtmlPosition
 * @see com.smartgwt.client.widgets.Canvas#getHtmlElement
 * @see com.smartgwt.client.widgets.Canvas#getHtmlPosition
 */
public interface HtmlElement {
}
