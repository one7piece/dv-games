
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to ChangeHandling.
 * @see com.smartgwt.client.widgets.form.fields.FormItem#getRedrawOnChange
 * @see com.smartgwt.client.widgets.form.fields.FormItem#getValidateOnChange
 */
public interface ChangeHandling {
}
