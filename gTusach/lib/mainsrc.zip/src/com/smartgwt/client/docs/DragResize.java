
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to DragResize.
 * @see com.smartgwt.client.widgets.Canvas#getEventEdge
 */
public interface DragResize {
}
