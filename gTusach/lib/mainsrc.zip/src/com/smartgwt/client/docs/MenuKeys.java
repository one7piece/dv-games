
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to MenuKeys.
 * @see com.smartgwt.client.widgets.menu.MenuItem#getKeys
 * @see com.smartgwt.client.widgets.menu.MenuItem#getKeyTitle
 */
public interface MenuKeys {
}
