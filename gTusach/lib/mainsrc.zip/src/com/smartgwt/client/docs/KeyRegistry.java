
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to KeyRegistry.
 * @see com.smartgwt.client.util.Page#registerKey
 * @see com.smartgwt.client.util.Page#unregisterKey
 */
public interface KeyRegistry {
}
