
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to EventRegistry.
 * @see com.smartgwt.client.util.Page#setEvent
 * @see com.smartgwt.client.util.Page#clearEvent
 * @see com.smartgwt.client.types.FireStyle
 */
public interface EventRegistry {
}
