
package com.smartgwt.client.docs;

/**
 * Parent/child relationships
 * @see com.smartgwt.client.types.DisplayNodeType
 */
public interface Ancestry {
}
