
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to Communication.
 * @see com.smartgwt.client.types.SendMethod
 */
public interface Communication {
}
