
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to DrawContext.
 */
public interface DrawContext {
}
