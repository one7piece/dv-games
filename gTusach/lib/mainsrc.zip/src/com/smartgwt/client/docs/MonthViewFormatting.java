
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to MonthViewFormatting.
 * @see com.smartgwt.client.widgets.calendar.Calendar#getDayBodyHTML
 */
public interface MonthViewFormatting {
}
