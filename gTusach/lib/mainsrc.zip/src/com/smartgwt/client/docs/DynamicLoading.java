
package com.smartgwt.client.docs;

/**
 */
public interface DynamicLoading {
}
