
package com.smartgwt.client.docs;

/**
 * Manipulating native form elements
 * @see com.smartgwt.client.widgets.form.DynamicForm#setItems
 * @see com.smartgwt.client.widgets.form.DynamicForm#setFields
 * @see com.smartgwt.client.widgets.form.DynamicForm#getFields
 * @see com.smartgwt.client.widgets.form.DynamicForm#getItems
 */
public interface Elements {
}
