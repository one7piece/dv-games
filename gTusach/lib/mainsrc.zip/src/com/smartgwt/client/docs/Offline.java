
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to Offline.
 * @see com.smartgwt.client.widgets.tree.TreeGrid#getOfflineNodeMessage
 */
public interface Offline {
}
