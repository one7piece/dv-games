
package com.smartgwt.client.docs;

/**
 * Server benefits - faster client-side processing Server neutral - heavy customization of XML
 * transform, if any, written in Java Client benefits - faster server-side processing Client
 * neutral - heavy customization of XML transform, if any, written in JavaScript
 */
public interface XmlClientVsServer {
}
