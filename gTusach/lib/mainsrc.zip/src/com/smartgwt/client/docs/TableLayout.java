
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to TableLayout.
 */
public interface TableLayout {
}
