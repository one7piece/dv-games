
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to Toolbar.
 * @see com.smartgwt.client.widgets.Dialog#getShowToolbar
 * @see com.smartgwt.client.widgets.Dialog#getAutoFocus
 */
public interface Toolbar {
}
