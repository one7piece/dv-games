
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to Identity.
 * @see com.smartgwt.client.data.DataSource#getID
 * @see com.smartgwt.client.data.DataSource#getAddGlobalId
 */
public interface Identity {
}
