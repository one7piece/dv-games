
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to FormValuesManager.
 * @see com.smartgwt.client.widgets.form.DynamicForm#getValuesManager
 */
public interface FormValuesManager {
}
