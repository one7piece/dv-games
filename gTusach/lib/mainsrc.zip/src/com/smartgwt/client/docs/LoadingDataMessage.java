
package com.smartgwt.client.docs;

/**
 * @see com.smartgwt.client.widgets.grid.ListGrid#getLoadingDataMessage
 * @see com.smartgwt.client.widgets.grid.ListGrid#getLoadingDataMessageStyle
 */
public interface LoadingDataMessage {
}
