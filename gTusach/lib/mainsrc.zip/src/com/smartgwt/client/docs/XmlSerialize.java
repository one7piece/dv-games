
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to XmlSerialize.
 * @see com.smartgwt.client.data.DataSourceField#getXmlAttribute
 * @see com.smartgwt.client.data.DataSourceField#getChildTagName
 * @see com.smartgwt.client.data.DataSourceField#getMultiple
 */
public interface XmlSerialize {
}
