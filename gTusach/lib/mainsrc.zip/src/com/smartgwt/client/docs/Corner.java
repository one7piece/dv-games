
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to Corner.
 * @see com.smartgwt.client.widgets.Scrollbar#getShowCorner
 * @see com.smartgwt.client.widgets.Scrollbar#getCornerSize
 */
public interface Corner {
}
