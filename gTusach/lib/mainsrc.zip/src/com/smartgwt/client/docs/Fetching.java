
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to Fetching.
 * @see com.smartgwt.client.types.FetchMode
 */
public interface Fetching {
}
