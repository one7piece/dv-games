
package com.smartgwt.client.docs;

/**
 * Utilities to render images
 */
public interface Image {
}
