
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to Minimize.
 * @see com.smartgwt.client.widgets.Window#getMinimizeHeight
 */
public interface Minimize {
}
