
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to Items.
 * @see com.smartgwt.client.widgets.tree.ResultTree#get
 * @see com.smartgwt.client.widgets.tree.ResultTree#getRange
 */
public interface Items {
}
