
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to Titles.
 * @see com.smartgwt.client.data.DataSource#getTitle
 * @see com.smartgwt.client.data.DataSource#getPluralTitle
 * @see com.smartgwt.client.data.DataSource#getTitleField
 */
public interface Titles {
}
