
package com.smartgwt.client.docs;

/**
 * The following APIs are all related to TextDirection.
 */
public interface TextDirection {
}
